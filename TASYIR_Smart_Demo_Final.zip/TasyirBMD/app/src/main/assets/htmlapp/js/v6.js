/* Tasyir — v6: تجربة أول تشغيل + بيانات تجريبية ذكية + مخزون بالمقاسات/الألوان
   طبقة إضافية فوق الكود الحالي (لا تغيّر مفاتيح البيانات القديمة؛ كل الحقول الجديدة اختيارية).
   حقول جديدة اختيارية على المنتج: vr (متغيّرات)، at (خصائص)، qk (كميات سريعة)، demo، dc.
   على المبيعات/الزبائن/الدفتر/المصاريف: demo فقط. وعلى db: onb. */
(()=>{
const IX=()=>({ar:0,fr:1,en:2}[LG()]||0);
const T3=(a,f,e)=>[a,f,e];
const pk=v=>Array.isArray(v)?v[IX()]:v;
const pad=(n,w)=>String(n).padStart(w,'0');
const fq=x=>String(r3(+x||0));
const slug=s=>String(s).replace(/[^A-Za-z0-9]+/g,'-').replace(/^-+|-+$/g,'').toUpperCase();
const DM=()=>L('بيانات تجريبية','Données de démo','Demo data');
Object.assign(T.ar,{box:'علبة',ctn:'كرتون',g:'g',ml:'ml'});
Object.assign(T.fr,{box:'boîte',ctn:'carton',g:'g',ml:'ml'});
Object.assign(T.en,{box:'box',ctn:'carton',g:'g',ml:'ml'});
const UL=u=>t(u||'u');
const hintsOn=()=>!(db.onb&&db.onb.hintsOff);

/* ---------- أيقونات إضافية (Lucide) ---------- */
Object.assign(_IC,{
shirt:'<path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/>',
droplet:'<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
smartphone:'<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
cup:'<path d="m6 8 1.75 12.28a2 2 0 0 0 2 1.72h4.54a2 2 0 0 0 2-1.72L18 8"/><path d="M5 8h14"/><path d="M7 15a6.47 6.47 0 0 1 5 0 6.47 6.47 0 0 0 5 0"/><path d="m12 8 1-6h2"/>',
lamp:'<path d="M8 2h8l4 10H4L8 2Z"/><path d="M12 12v6"/><path d="M8 22v-2c0-1.1.9-2 2-2h4a2 2 0 0 1 2 2v2H8Z"/>',
hammer:'<path d="m15 12-8.373 8.373a1 1 0 1 1-3-3L12 9"/><path d="m18 15 4-4"/><path d="m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172V7l-2.26-2.26a6 6 0 0 0-4.202-1.756L9 2.96l.92.82A6.18 6.18 0 0 1 12 8.4V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5"/>',
car:'<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
bookopen:'<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
sprout:'<path d="M7 20h10"/><path d="M10 20c5.5-2.5.8-6.4 3-10"/><path d="M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z"/><path d="M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z"/>',
apple:'<path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z"/><path d="M10 2c1 .5 2 2 2 5"/>',
armchair:'<path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"/><path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z"/><path d="M5 18v2"/><path d="M19 18v2"/>'});

/* ---------- تسميات الخصائص ---------- */
const AL={sku:['SKU','SKU','SKU'],brand:['الماركة','Marque','Brand'],supplier:['المورد','Fournisseur','Supplier'],gender:['الجنس','Genre','Gender'],
size:['الحجم / المقاس','Taille','Size'],scent:['العطر','Parfum','Scent'],lot:['الدفعة (Lot)','Lot','Batch / Lot'],exp:['تاريخ الانتهاء','Péremption','Expiry'],
prod:['تاريخ الإنتاج','Production','Produced'],model:['الموديل','Modèle','Model'],ram:['RAM','RAM','RAM'],imei:['IMEI / Serial','IMEI / Série','IMEI / Serial'],
warranty:['الضمان','Garantie','Warranty'],cond:['الحالة','État','Condition'],power:['القدرة','Puissance','Power'],len:['الطول','Longueur','Length'],
conn:['الموصل','Connecteur','Connector'],compat:['التوافق','Compatibilité','Compatibility'],material:['المادة','Matière','Material'],dim:['الأبعاد','Dimensions','Dimensions'],
ref:['المرجع','Référence','Reference'],oem:['OEM','OEM','OEM'],age:['العمر','Âge','Age'],wt:['الوزن','Poids','Weight'],season:['الموسم','Saison','Season'],
type:['النوع','Type','Type'],pack:['التعبئة','Conditionnement','Packing'],color:['اللون','Couleur','Color'],isbn:['ISBN / باركود','ISBN / code','ISBN / barcode']};
const alb=k=>AL[k]?AL[k][IX()]:k;
const ALR={};Object.keys(AL).forEach(k=>AL[k].forEach(l=>ALR[l.toLowerCase()]=k));
const NEW=T3('جديد','Neuf','New'),M12=T3('12 شهرًا','12 mois','12 months'),M6=T3('6 أشهر','6 mois','6 months'),
 MEN=T3('رجالي','Homme','Men'),UNI=T3('للجنسين','Unisexe','Unisex'),PLANT=T3('نبات','Plante','Plant');

/* ---------- الفئات والمنتجات التجريبية (5 لكل فئة) ----------
   n اسم، u وحدة، c تكلفة، s بيع، w جملة (بالدينار)، m حد أدنى، st مخزون،
   v متغيّرات [[اسم،كمية]]، a خصائص، qk كميات سريعة [[كمية،'b'|'p']] (b قارورة، p سطل) */
const CATS=[
{id:'cloth',sk:'CLO',ic:'shirt',n:T3('الملابس والأزياء','Vêtements & mode','Clothing & fashion'),p:[
 {n:'T-Shirt Basic',c:600,s:1200,w:950,m:3,v:[['Noir / S',4],['Noir / M',8],['Noir / L',3],['Noir / XL',0],['Blanc / S',3],['Blanc / M',4],['Blanc / L',2]],a:[['brand','Urban Line'],['gender',MEN],['supplier','Atelier Textile Alger']]},
 {n:'Jean Slim',c:1500,s:2800,w:2300,m:3,v:[['Bleu / 38',3],['Bleu / 40',6],['Bleu / 42',5],['Bleu / 44',0],['Noir / 40',4],['Noir / 42',2]],a:[['brand','Denim Co.'],['gender',MEN],['supplier','Import Denim Oran']]},
 {n:'Sweatshirt',c:1300,s:2400,w:1950,m:3,v:[['Gris / M',5],['Gris / L',4],['Gris / XL',2],['Noir / M',6],['Noir / L',0],['Noir / XL',3]],a:[['brand','Cozy Wear'],['gender',UNI],['supplier','Atelier Textile Alger']]},
 {n:'Veste légère',c:2200,s:3900,w:3300,m:2,v:[['Beige / M',2],['Beige / L',3],['Kaki / M',4],['Kaki / L',1]],a:[['brand','Nord Wear'],['gender',MEN],['supplier','Confection Sétif']]},
 {n:'Polo classique',c:800,s:1600,w:1300,m:3,v:[['Blanc / S',5],['Blanc / M',7],['Blanc / L',4],['Marine / S',3],['Marine / M',6],['Marine / L',2]],a:[['brand','Classic Polo'],['gender',MEN],['supplier','Confection Sétif']]}]},
{id:'perf',sk:'PRF',ic:'droplet',n:T3('التجميل والعطور','Beauté & parfums','Beauty & fragrance'),p:[
 {n:'Eau de Parfum Femme',u:'ml',c:30,s:55,w:45,m:20,st:120,qk:[[5],[10],[20],[50,'b']],a:[['brand','Maison Aura'],['size','50 ml'],['scent','Floral · Rose'],['lot','LOT-PF-0426'],['exp','+540'],['supplier','Parfums Import Alger']]},
 {n:'Eau de Parfum Homme',u:'ml',c:22,s:40,w:32,m:20,st:63.5,qk:[[10],[20],[50],[100,'b']],a:[['brand','Maison Aura'],['size','100 ml'],['scent','Boisé · Ambre'],['lot','LOT-PH-0426'],['exp','+540'],['supplier','Parfums Import Alger']]},
 {n:'Huile parfumée',u:'ml',c:60,s:90,w:75,m:15,st:12.5,qk:[[5],[10,'b']],a:[['brand','Dar El Oud'],['size','10 ml'],['scent','Oud · Musc'],['lot','LOT-HP-0326'],['exp','+700'],['supplier','Parfums Import Alger']]},
 {n:'Shampooing',c:400,s:650,w:550,m:5,st:18,a:[['brand','Pure Hair'],['size','250 ml'],['lot','LOT-SH-0526'],['exp','+420'],['supplier','Cosmétiques Blida']]},
 {n:'Crème hydratante',c:600,s:950,w:800,m:5,st:12,a:[['brand','Soft Skin'],['size','50 ml'],['lot','LOT-CH-0526'],['exp','+480'],['supplier','Cosmétiques Blida']]}]},
{id:'phone',sk:'ELC',ic:'smartphone',n:T3('الهواتف والإلكترونيات','Téléphones & électronique','Phones & electronics'),p:[
 {n:'Smartphone Galaxy A',c:32000,s:38500,w:36500,m:2,v:[['Noir / 128 GB',3],['Bleu / 128 GB',2],['Noir / 256 GB',0]],a:[['brand','Samsung'],['model','Galaxy A'],['ram','6 GB'],['imei','DEMO-IMEI-0001'],['warranty',M12],['cond',NEW],['supplier','Mobile Distribution Alger']]},
 {n:'Smartphone Redmi',c:24000,s:28900,w:27000,m:2,v:[['Black / 256 GB',4],['Blue / 256 GB',2],['Black / 128 GB',5]],a:[['brand','Xiaomi'],['model','Redmi Note'],['ram','8 GB'],['imei','DEMO-IMEI-0002'],['warranty',M12],['cond',NEW],['supplier','Mobile Distribution Alger']]},
 {n:'Wireless Earbuds',c:1900,s:3200,w:2700,m:3,v:[['Noir',9],['Blanc',5]],a:[['brand','SoundGo'],['model','EB-200'],['warranty',M6],['cond',NEW],['supplier','Mobile Distribution Alger']]},
 {n:'USB-C Fast Charger',c:900,s:1700,w:1400,m:5,st:25,a:[['brand','VoltPlus'],['power','33 W'],['conn','USB-C'],['compat','Android · iPhone 15'],['color','Blanc'],['supplier','Accessoires Mobile Alger']]},
 {n:'USB-C Cable',c:250,s:600,w:450,m:8,st:40,a:[['power','60 W'],['len','1 m'],['conn','USB-C → USB-C'],['compat',T3('هواتف وحواسيب','Téléphones & PC','Phones & laptops')],['color','Noir'],['supplier','Accessoires Mobile Alger']]}]},
{id:'food',sk:'FOD',ic:'cup',n:T3('الغذاء والمشروبات','Alimentation & boissons','Food & drinks'),p:[
 {n:'Coca-Cola',c:85,s:120,w:100,m:24,st:96,a:[['brand','Coca-Cola'],['size','1 L'],['pack',T3('1 كرتون = 24 قطعة','1 carton = 24 unités','1 carton = 24 units')],['lot','LOT-CC-2611'],['prod','-20'],['exp','+160'],['supplier','Distribution Boissons Alger']]},
 {n:T3('مياه معدنية','Eau minérale','Mineral water'),c:28,s:40,w:34,m:24,st:144,a:[['size','1.5 L'],['pack',T3('1 كرتون = 6 قطع','1 carton = 6 unités','1 carton = 6 units')],['lot','LOT-EM-0826'],['prod','-30'],['exp','+330'],['supplier','Distribution Boissons Alger']]},
 {n:T3('بسكويت','Biscuits','Biscuits'),u:'box',c:110,s:170,w:145,m:10,st:30,a:[['size','200 g'],['pack',T3('1 كرتون = 12 علبة','1 carton = 12 boîtes','1 carton = 12 boxes')],['lot','LOT-BS-0926'],['prod','-45'],['exp','+200'],['supplier','Grossiste Alimentaire Alger']]},
 {n:T3('شوكولا','Chocolat','Chocolate'),c:125,s:190,w:160,m:12,st:48,a:[['size','100 g'],['pack',T3('1 علبة = 24 قطعة','1 boîte = 24 pièces','1 box = 24 pieces')],['lot','LOT-CH-1026'],['prod','-25'],['exp','+240'],['supplier','Grossiste Alimentaire Alger']]},
 {n:T3('عصير','Jus de fruits','Fruit juice'),u:'ctn',c:780,s:1100,w:980,m:3,st:8,a:[['size','12 × 1 L'],['pack',T3('1 كرتون = 12 قطعة','1 carton = 12 unités','1 carton = 12 units')],['lot','LOT-JS-0726'],['prod','-15'],['exp','+150'],['supplier','Distribution Boissons Alger']]}]},
{id:'home',sk:'HOM',ic:'lamp',n:T3('المنزلية والديكور','Maison & décoration','Home & decor'),p:[
 {n:T3('طقم كؤوس','Set de verres','Glass set'),c:950,s:1600,w:1350,m:3,st:14,a:[['material',T3('زجاج','Verre','Glass')],['size','6 pcs'],['dim','Ø 7 cm'],['color',T3('شفاف','Transparent','Clear')],['supplier','Maison Déco Alger']]},
 {n:T3('مقلاة','Poêle','Frying pan'),c:1100,s:1900,w:1600,m:2,v:[['Noir / 24 cm',6],['Noir / 28 cm',4],['Rouge / 28 cm',0]],a:[['material','Aluminium antiadhésif'],['supplier','Maison Déco Alger']]},
 {n:T3('علبة تخزين','Boîte de rangement','Storage box'),c:350,s:650,w:520,m:3,v:[['Transparent / 5 L',10],['Transparent / 10 L',6],['Transparent / 20 L',0]],a:[['material','Plastique PP'],['supplier','Plastiques Blida']]},
 {n:T3('مصباح ديكور','Lampe décorative','Decor lamp'),c:1400,s:2500,w:2100,m:2,v:[['Doré',5],['Noir',3]],a:[['material','Métal'],['dim','25 × 40 cm'],['supplier','Maison Déco Alger']]},
 {n:T3('وسادة ديكور','Coussin décoratif','Decor cushion'),c:450,s:900,w:750,m:3,v:[['Beige',12],['Gris',7]],a:[['material','Velours'],['dim','45 × 45 cm'],['supplier','Textile Maison Sétif']]}]},
{id:'hard',sk:'HRD',ic:'hammer',n:T3('العتاد ومواد البناء','Quincaillerie & bâtiment','Hardware & building'),p:[
 {n:'Vis 4x40',u:'kg',c:320,s:450,w:390,m:3,st:18.5,qk:[[0.5],[1],[2]],a:[['size','4 × 40 mm'],['material','Acier zingué'],['supplier','Quincaillerie Gros Alger']]},
 {n:'Cheville 8mm',c:4,s:9,w:7,m:100,st:420,a:[['size','8 mm'],['material','Nylon'],['supplier','Quincaillerie Gros Alger']]},
 {n:'Câble électrique',u:'m',c:60,s:85,w:75,m:20,st:100,qk:[[1],[5],[10],[25]],a:[['size','2,5 mm²'],['material',T3('نحاس','Cuivre','Copper')],['color','Bleu'],['supplier','Électricité Gros Alger']]},
 {n:'Peinture intérieure',u:'l',c:380,s:520,w:470,m:10,st:45,qk:[[1],[5],[15,'p']],a:[['color','Blanc mat'],['size',T3('سطل 15 L','Seau 15 L','15 L pail')],['lot','LOT-PT-0626'],['supplier','Peintures Algérie Gros']]},
 {n:'Rouleau peinture',c:280,s:520,w:420,m:4,st:22,a:[['brand','ProPaint'],['size','22 cm'],['supplier','Peintures Algérie Gros']]}]},
{id:'auto',sk:'AUT',ic:'car',n:T3('السيارات وقطع الغيار','Auto & pièces détachées','Auto & spare parts'),p:[
 {n:'Filtre à huile',c:450,s:850,w:700,m:4,st:16,a:[['brand','MecaFilter'],['compat','Renault Clio · Dacia Logan'],['ref','FH-1520'],['oem','8200768913'],['warranty',M6],['cond',NEW],['supplier','Pièces Auto Alger']]},
 {n:'Plaquettes de frein',c:1500,s:2600,w:2200,m:2,v:[['Avant / PB-210',6],['Avant / PB-310',3],['Arrière / PB-211',0]],a:[['brand','BrakePro'],['compat','Renault Symbol · Clio'],['oem','7701208265'],['warranty',M6],['cond',NEW],['supplier','Pièces Auto Alger']]},
 {n:'Filtre à air',c:600,s:1100,w:900,m:3,st:9,a:[['brand','MecaFilter'],['compat','Peugeot 208 · Citroën C3'],['ref','FA-3301'],['oem','1444VK'],['warranty',M6],['cond',NEW],['supplier','Pièces Auto Alger']]},
 {n:'Batterie',c:9500,s:12900,w:11500,m:1,v:[['60 Ah',4],['70 Ah',2],['80 Ah',0]],a:[['brand','PowerCell'],['compat',T3('سيارات المدينة','Citadines','City cars')],['warranty',M12],['cond',NEW],['supplier','Batteries Gros Alger']]},
 {n:'Ampoule automobile',c:180,s:380,w:300,m:5,v:[['H4',30],['H7',18],['H1',0]],a:[['brand','LumiCar'],['power','55 W · 12 V'],['cond',NEW],['supplier','Pièces Auto Alger']]}]},
{id:'stat',sk:'LIB',ic:'bookopen',n:T3('المكتبات والألعاب','Librairie & jouets','Stationery & toys'),p:[
 {n:'Cahier A4',c:70,s:130,w:105,m:10,v:[['96 pages / Grands carreaux',40],['96 pages / Petits carreaux',24],['192 pages / Grands carreaux',0]],a:[['brand','Papier Plus'],['size','A4'],['supplier','Papeterie Gros Alger']]},
 {n:'Stylo bleu',c:15,s:30,w:22,m:30,st:150,a:[['brand','WriteWell'],['color','Bleu'],['pack',T3('علبة = 50 قلمًا','boîte = 50 stylos','box = 50 pens')],['supplier','Papeterie Gros Alger']]},
 {n:'Sac scolaire',c:1800,s:3200,w:2700,m:2,v:[['Bleu',6],['Rose',4],['Noir',0]],a:[['brand','School Pro'],['age',T3('6–12 سنة','6–12 ans','6–12 years')],['size','40 × 30 cm'],['supplier','Papeterie Gros Alger']]},
 {n:'Puzzle',c:350,s:750,w:600,m:3,st:11,a:[['brand','Fun Kids'],['size','100 pcs'],['age',T3('6 سنوات فأكثر','6 ans et +','6+ years')],['supplier','Jouets Import Alger']]},
 {n:T3('لعبة تعليمية','Jeu éducatif','Educational game'),c:900,s:1700,w:1400,m:2,st:7,a:[['brand','Fun Kids'],['age',T3('4 سنوات فأكثر','4 ans et +','4+ years')],['supplier','Jouets Import Alger']]}]},
{id:'agri',sk:'AGR',ic:'sprout',n:T3('الزراعة والحيوانات','Agriculture & animaux','Agriculture & pets'),p:[
 {n:'Semences tomate',c:60,s:130,w:100,m:10,st:60,a:[['brand','AgroSemis'],['wt','5 g'],['season',T3('الربيع','Printemps','Spring')],['type',PLANT],['lot','LOT-ST-0126'],['exp','+300'],['supplier','Agro Distribution Blida']]},
 {n:'Engrais',u:'kg',c:90,s:160,w:130,m:10,st:120,qk:[[1],[5],[25]],a:[['type',PLANT],['pack',T3('كيس 25 كغ (بالوزن)','Sac 25 kg (au poids)','25 kg bag (by weight)')],['lot','LOT-EG-0226'],['exp','+700'],['supplier','Agro Distribution Blida']]},
 {n:'Terreau',c:450,s:780,w:650,m:4,st:15,a:[['wt','20 L'],['season',T3('كل المواسم','Toute l\'année','All year')],['type',PLANT],['lot','LOT-TR-0326'],['supplier','Agro Distribution Blida']]},
 {n:'Croquettes chien',c:1300,s:1950,w:1750,m:3,st:8,a:[['brand','PetVital'],['wt',T3('كيس 2 كغ','Sac 2 kg','2 kg bag')],['type',T3('كلب','Chien','Dog')],['lot','LOT-CD-0426'],['exp','+240'],['supplier','Animalerie Gros Alger']]},
 {n:T3('طعام القطط','Nourriture chat','Cat food'),c:1100,s:1650,w:1450,m:3,st:11,a:[['brand','PetVital'],['wt',T3('كيس 1.5 كغ','Sac 1,5 kg','1.5 kg bag')],['type',T3('قط','Chat','Cat')],['lot','LOT-NC-0426'],['exp','+240'],['supplier','Animalerie Gros Alger']]}]},
{id:'furn',sk:'FUR',ic:'armchair',n:T3('الأثاث والتجهيزات','Mobilier & équipement','Furniture & fittings'),p:[
 {n:'Chaise bureau',c:6500,s:9800,w:8800,m:1,v:[['Noir',5],['Gris',3],['Bleu',0]],a:[['model','CH-210'],['material','Tissu mesh'],['dim','60 × 60 × 110 cm'],['warranty',M12],['supplier','Meubles Gros Alger']]},
 {n:'Table bureau',c:9000,s:13500,w:12000,m:1,v:[['120 cm / Chêne',3],['140 cm / Chêne',2],['140 cm / Blanc',0]],a:[['model','TB-140'],['material','Mélaminé'],['warranty',M12],['supplier','Meubles Gros Alger']]},
 {n:'Armoire',c:28000,s:39000,w:35000,m:1,v:[['2 portes / Blanc',2],['3 portes / Blanc',1],['3 portes / Chêne',0]],a:[['model','AR-300'],['material','MDF'],['warranty',M12],['supplier','Meubles Gros Alger']]},
 {n:'Meuble TV',c:8500,s:13200,w:11800,m:1,st:4,a:[['model','TV-160'],['material','MDF'],['color','Noyer'],['dim','160 × 40 × 45 cm'],['warranty',M12],['supplier','Meubles Gros Alger']]},
 {n:'Étagère',c:2800,s:4600,w:4000,m:2,v:[['Noir / 5 niveaux',6],['Blanc / 5 niveaux',0],['Noir / 4 niveaux',4]],a:[['model','ET-5'],['material','Métal & bois'],['supplier','Meubles Gros Alger']]}]},
{id:'fresh',sk:'FRS',ic:'apple',n:T3('المنتجات الطازجة','Produits frais','Fresh produce'),p:[
 {n:'Poulet',u:'kg',c:480,s:650,w:580,m:5,st:23.5,qk:[[0.5],[1],[1.5],[2]],a:[['type',T3('طازج','Frais','Fresh')],['supplier','Abattoir Blida']]},
 {n:'Viande bovine',u:'kg',c:1500,s:1900,w:1750,m:4,st:14,qk:[[0.25],[0.5],[1],[2]],a:[['type',T3('طازج','Frais','Fresh')],['supplier','Boucherie Gros Alger']]},
 {n:'Tomate',u:'kg',c:55,s:90,w:75,m:10,st:40,qk:[[0.5],[1],[2],[5]],a:[['type',T3('طازج','Frais','Fresh')],['supplier','Marché de gros Alger']]},
 {n:'Pomme de terre',u:'kg',c:45,s:70,w:60,m:15,st:85,qk:[[1],[2],[5],[10]],a:[['type',T3('طازج','Frais','Fresh')],['supplier','Marché de gros Alger']]},
 {n:'Pomme',u:'kg',c:150,s:220,w:190,m:8,st:32,qk:[[0.5],[1],[2],[5]],a:[['type',T3('طازج','Frais','Fresh')],['supplier','Marché de gros Alger']]}]},
{id:'gen',sk:'GEN',ic:'boxes',n:T3('تجارة عامة / أخرى','Commerce général / autre','General trade / other'),p:[
 {n:'Pile AA',c:80,s:150,w:120,m:10,st:60,a:[['pack',T3('علبة = 4 بطاريات','pack = 4 piles','pack = 4 batteries')],['supplier','Grossiste Général Alger']]},
 {n:'Sac plastique',c:250,s:400,w:330,m:5,st:30,a:[['pack',T3('لفّة','Rouleau','Roll')],['supplier','Grossiste Général Alger']]},
 {n:'Ruban adhésif',c:60,s:120,w:95,m:10,st:45,a:[['size','48 mm × 50 m'],['supplier','Grossiste Général Alger']]},
 {n:'Ampoule LED',c:150,s:280,w:230,m:8,st:35,a:[['power','9 W'],['conn','E27'],['supplier','Grossiste Général Alger']]},
 {n:T3('بطارية زر','Batterie bouton','Button battery'),c:40,s:90,w:70,m:10,st:50,a:[['model','CR2032'],['supplier','Grossiste Général Alger']]}]}];
const CI=id=>CATS.find(c=>c.id===id);
const ICOL=['--chart1','--chart2','--chart3','--chart4','--chart5','--chart6','--chart7','--chart8'];

/* ---------- مولّد البيانات ---------- */
const ean=b=>{let k=0;for(let i=0;i<12;i++)k+=(+b[i])*(i%2?3:1);return b+((10-k%10)%10)};
const bcFor=(ci,pi,vi)=>ean('29'+pad(ci,2)+pad(pi,1)+pad(vi,2)+'00000');
const dateOff=(k,v)=>(k==='exp'||k==='prod')&&/^[+-]\d+$/.test(String(v))?iso(addD(new Date(),parseInt(v,10))):v;
function mkProd(C,ci,d,pi){
 const id='dm_'+C.id+'_'+pi,sk=C.sk+'-'+pad(pi+1,3);
 const p={id,arch:false,img:'',name:pk(d.n),bc:bcFor(ci,pi+1,0),cost:d.c*100,price:d.s*100,stock:0,min:d.m,unit:d.u||'u',fam:pk(C.n),p2:0,p3:d.w*100,tierMin:0,demo:1,dc:C.id};
 if(d.v){p.vr=d.v.map((x,vi)=>({id:id+'_v'+vi,n:x[0],q:x[1],bc:bcFor(ci,pi+1,vi+1),sku:sk+'-'+slug(x[0])}));p.stock=r3(p.vr.reduce((a,v)=>a+v.q,0))}
 else p.stock=d.st;
 p.at=[['sku',sk]].concat((d.a||[]).map(([k,v])=>[k,dateOff(k,v)]));
 if(d.qk)p.qk=d.qk.map(x=>({q:x[0],t:x[1]||''}));
 return p}
const qtyFor=p=>({kg:1.2,ml:20,m:15,l:5,g:250}[p.unit])||((p.vr||p.price>=1000000)?1:2);
function seedDemo(ids){
 const now=new Date(),cats=CATS.filter(c=>ids.includes(c.id));
 cats.forEach(C=>{const ci=CATS.indexOf(C)+1;C.p.forEach((d,pi)=>{const id='dm_'+C.id+'_'+pi;if(!db.products.some(x=>x.id===id))db.products.push(mkProd(C,ci,d,pi))})});
 const c1={id:'dm_c1',name:'Karim B. · DEMO',phone:'0555 00 00 01',tier:'p1',demo:1},c2={id:'dm_c2',name:'Samira L. · DEMO',phone:'0555 00 00 02',tier:'p1',demo:1};
 [c1,c2].forEach(c=>{if(!db.customers.some(x=>x.id===c.id))db.customers.push(c)});
 let n=0;
 const mk=(cid,off,ix,cust,partial)=>{const prods=db.products.filter(p=>p.dc===cid&&p.demo),ls=[];
  ix.forEach(i=>{const p=prods[i];if(!p)return;let v=null;if(p.vr)v=p.vr.filter(x=>x.q>0)[(i+off)%Math.max(1,p.vr.filter(x=>x.q>0).length)];
   const q=qtyFor(p),pr=p.price,l={pid:p.id,name:p.name+(v?' · '+v.n:''),qty:q,price:pr,cost:p.cost,total:Math.round(pr*q),tier:'p1'};if(v)l.vid=v.id;ls.push(l)});
  if(!ls.length)return;
  const dt=new Date(now);dt.setDate(dt.getDate()-off);dt.setHours(off?10+n%6:Math.max(8,now.getHours()-1),(n*17)%60,0,0);if(!off&&dt>now)dt.setTime(now.getTime()-(n+1)*600000);
  const sub=ls.reduce((a,l)=>a+l.total,0),paid=partial?Math.round(sub*.6):sub,debt=sub-paid;n++;
  const s={id:'dm_s'+n,no:'DEMO-'+pad(n,3),d:dt.toISOString(),day:iso(dt),lines:ls,sub,disc:0,total:sub,paid,debt,cust:cust||null,tier:'p1',note:'',demo:1};
  db.sales.push(s);if(debt>0)db.ledger.push({id:'dm_l'+n,c:cust,t:'debt',a:debt,d:s.d,ref:s.no,demo:1})};
 cats.forEach((C,k)=>{mk(C.id,0,[0,2],k===0?'dm_c1':'',k===0);if(cats.length<=6)mk(C.id,(k%5)+1,[1,3],'',false);if(cats.length<=3)mk(C.id,((k+2)%5)+1,[4,0],'',false)});
 db.sales.sort((a,b)=>a.d<b.d?-1:1);
 const lg=(id,c,ty,a,off,n_)=>{const dt=new Date(now);dt.setDate(dt.getDate()-off);db.ledger.push({id,c,t:ty,a:a*100,d:dt.toISOString(),ref:'MAN',n:n_||'',demo:1})};
 lg('dm_l_a','dm_c2','debt',2650,2);lg('dm_l_b','dm_c1','pay',1000,0,L('دفعة','Versement','Payment'));
 const ex=(id,nm,a,off)=>{const dt=new Date(now);dt.setDate(dt.getDate()-off);db.expenses.push({id,n:nm+' · DEMO',a:a*100,day:iso(dt),d:dt.toISOString(),demo:1})};
 ex('dm_e1',L('نقل','Transport','Transport'),600,0);ex('dm_e2',L('كهرباء','Électricité','Electricity'),1450,0);ex('dm_e3',L('أكياس وتغليف','Emballage','Packaging'),900,1);
 db.onb=Object.assign(db.onb||{},{done:1,demo_seeded:true,cats:cats.map(c=>c.id),at:Date.now()});
 saveNow()}
const demoCount=()=>db.products.filter(p=>p.demo).length+db.sales.filter(s=>s.demo).length+db.customers.filter(c=>c.demo).length+db.expenses.filter(e=>e.demo).length;
function clearDemo(){
 try{localStorage.setItem(K+'_safety',JSON.stringify(db))}catch(e){}
 db.sales=db.sales.filter(s=>!s.demo);db.ledger=db.ledger.filter(l=>!l.demo);db.expenses=db.expenses.filter(e=>!e.demo);
 db.customers=db.customers.filter(c=>!c.demo||db.ledger.some(l=>l.c===c.id)||db.sales.some(s=>s.cust===c.id));db.customers.forEach(c=>{delete c.demo});
 db.products=db.products.filter(p=>!p.demo);
 const ok=l=>db.products.some(p=>p.id===l.pid);cart=cart.filter(ok);(db.held||[]).forEach(h=>{h.cart=h.cart.filter(ok)});db.held=(db.held||[]).filter(h=>h.cart.length);
 if(db.onb)db.onb.demoCleared=true;_bsK=-1;saveNow();ov.innerHTML='';pf='';sub='';R();toast('[ok] '+L('تم مسح البيانات التجريبية','Données de démo supprimées','Demo data cleared'))}
function clearDemoAsk(){sheet(`<h3>${ic('trash')} ${L('مسح البيانات التجريبية','Supprimer les données de démo','Clear demo data')}</h3><div class="k" style="margin:8px 0 14px;font-size:14px">${L('سيتم حذف المنتجات والبيانات التجريبية فقط. منتجاتك وبيعاتك الحقيقية لن تُمسّ.','Seuls les produits et données de démo seront supprimés. Vos produits et ventes réels ne sont pas touchés.','Only demo products and data will be deleted. Your real products and sales are untouched.')}</div><div class="bar"><button class="b r" style="flex:1" onclick="clearDemo()">${ic('trash')} ${t('del')}</button><button class="b s" style="flex:1" onclick="ov.innerHTML=''">${t('cancel')}</button></div>`)}

/* ---------- المخزون الذكي ---------- */
const hasV=p=>!!(p&&p.vr&&p.vr.length);
const vst=(p,v)=>v.q<=0?'out':v.q<=p.min?'low':'ok';
const vsum=p=>r3(p.vr.reduce((a,v)=>a+v.q,0));
function vSyncAll(){db.products.forEach(p=>{if(hasV(p)){const s=vsum(p);if(p.stock!==s)p.stock=s}})}
const phi=(p,sz)=>{if(p.img)return th(p);const c=CI(p.dc),k=c?CATS.indexOf(c)%8:0;return`<span class="phi" style="--c:var(${ICOL[k]});${sz?`width:${sz}px;height:${sz}px`:''}">${ic(c?c.ic:'package')}</span>`};
const STL=()=>({ok:L('متوفر','En stock','In stock'),low:L('منخفض','Faible','Low'),out:L('نفد','Épuisé','Out')});
stockPill=function(p){const s=stockState(p);return`<span class="pill ${s}">${STL()[s]}<span class="num"> · ${fq(p.stock)} ${UL(p.unit)}</span></span>`};
const remTxt=p=>{const u=p.unit||'u',s=`${fq(p.stock)} ${UL(u)}`;return p.stock>0&&['ml','g','kg','l','m'].includes(u)?s+' '+L('متبقية','restant','left'):s};
function vchips(p,max){if(!hasV(p))return'';const a=p.vr.slice(0,max||99),more=p.vr.length-a.length;
 return`<div class="vcs">${a.map(v=>{const s=vst(p,v);return`<span class="vc ${s}">${esc(v.n)} <b class="num">${s==='out'?L('نفد','Épuisé','Out'):fq(v.q)}</b></span>`}).join('')}${more>0?`<span class="vc">+${more}</span>`:''}</div>`}
const demoTag=p=>p.demo?` <span class="tag dm">${DM()}</span>`:'';

/* ---------- اختيار المقاس/اللون والكميات السريعة ---------- */
function cartAdd(l){const e=cart.find(x=>x.pid===l.pid&&(x.vid||'')===(l.vid||'')&&!x.man);if(e)e.qty=r3(e.qty+l.qty);else cart.push(l);reprice();window._fl=l.pid;cartUp();try{hap('tick')}catch(e_){}}
function addVar(pid,vid){const p=db.products.find(x=>x.id===pid),v=p&&hasV(p)&&p.vr.find(x=>x.id===vid);if(!v)return;ov.innerHTML='';
 cartAdd({pid,vid,vn:v.n,name:p.name+' · '+v.n,price:p.price,cost:p.cost,qty:1,tier:tier});if(p.price<p.cost)toast(t('warn'))}
function addQ(pid,q,quiet){const p=db.products.find(x=>x.id===pid);q=r3(N(q));if(!p||q<=0)return;if(!quiet)ov.innerHTML='';
 cartAdd({pid,name:p.name,price:p.price,cost:p.cost,qty:q,tier:tier})}
function pickV(pid){const p=db.products.find(x=>x.id===pid);if(!p)return;const allow=ST().sellZero||ST().allowNeg||ST().noQty,G={};
 p.vr.forEach(v=>{const a=v.n.split(' / '),g=a.length>1?a[0]:'';(G[g]=G[g]||[]).push([v,a.length>1?a.slice(1).join(' / '):v.n])});
 sheet(`<h3>${esc(p.name)}</h3><div class="k" style="margin-bottom:6px">${L('اختر المقاس أو اللون','Choisissez taille / couleur','Choose size / color')}</div>`+Object.entries(G).map(([g,a])=>`${g?`<div class="vgh">${esc(g)}</div>`:''}<div class="vg">${a.map(([v,lb])=>{const s=vst(p,v),dis=s==='out'&&!allow;return`<button class="vb ${s}" ${dis?'disabled':`onclick="addVar('${p.id}','${v.id}')"`}><span>${esc(lb)}</span><small class="num">${s==='out'?L('نفد','Épuisé','Out'):fq(v.q)}</small></button>`}).join('')}</div>`).join('')+`<button class="b s" style="width:100%;margin-top:12px" onclick="ov.innerHTML=''">${t('cancel')}</button>`)}
function pickQ(pid){const p=db.products.find(x=>x.id===pid);if(!p)return;const u=UL(p.unit),tg={b:L('قارورة','Flacon','Bottle'),p:L('سطل','Seau','Pail')};
 sheet(`<h3>${esc(p.name)}</h3><div class="k" style="margin-bottom:6px">${M(p.price)} / ${u} · ${remTxt(p)}</div><div class="vg">${p.qk.map(x=>`<button class="vb ${x.q>p.stock&&!(ST().sellZero||ST().allowNeg||ST().noQty)?'out':'ok'}" ${x.q>p.stock&&!(ST().sellZero||ST().allowNeg||ST().noQty)?'disabled':`onclick="addQ('${p.id}',${x.q})"`}><span>${x.t?tg[x.t]+' · ':''}${fq(x.q)} ${u}</span><small class="num">${M(Math.round(p.price*x.q))}</small></button>`).join('')}</div>
 <label class="k" style="margin-top:10px">${L('كمية أخرى','Autre quantité','Other quantity')} (${u})</label><div class="bar"><input id="qkc" type="number" step="any" inputmode="decimal" style="margin:0;flex:1"><button class="b" onclick="addQ('${p.id}',qkc.value)">${ic('plus')} ${t('add')}</button></div>
 <button class="b s" style="width:100%;margin-top:10px" onclick="ov.innerHTML=''">${t('cancel')}</button>`);setTimeout(()=>{const e=document.getElementById('qkc');if(e&&0)e.focus()},60)}
const _ap6=addP;
addP=function(id,q){const p=db.products.find(x=>x.id===id);
 if(hasV(p)){const f=window._fv6;window._fv6=null;if(f&&f.pid===id&&Date.now()-f.t<3000){addVar(id,f.vid);return}pickV(id);return}
 if(p&&p.qk&&p.qk.length){if(q){const b=p.qk.find(x=>x.t==='b')||p.qk[0];addQ(id,b.q,1);return}pickQ(id);return}
 _ap6(id,q)};
const _fp6=findP;
findP=function(c){const p=_fp6(c);if(p)return p;const a=[c,'0'+c,String(c).replace(/^0+/,'')];
 for(const x of db.products){if(x.arch||!hasV(x))continue;const v=x.vr.find(y=>y.bc&&a.includes(y.bc));if(v){window._fv6={pid:x.id,vid:v.id,t:Date.now()};return x}}return p};
posScan=function(c){const p=findP(c);if(!p)return[0,t('nof')+': '+c];if(window._lk){showProd(p);return[1,p.name]}addP(p.id,1);
 const l=cart.find(x=>x.pid===p.id);return[1,l?t('added')+l.name+' ×'+l.qty:p.name]};
showProd=function(p){pDet(p.id)};
const _cu6=cartUp;
cartUp=function(){_cu6();const b=document.getElementById('cartbox');if(!b)return;b.querySelectorAll('.ln').forEach((e,i)=>{const l=cart[i];if(!l)return;const p=db.products.find(x=>x.id===l.pid);
 if(p&&p.unit&&p.unit!=='u'){const k=e.querySelector('.k');if(k&&!k.querySelector('.ut'))k.insertAdjacentHTML('beforeend',` <span class="tag ut">/ ${esc(UL(p.unit))}</span>`)}})};

/* ---------- البيع: مخزون المتغيّرات ---------- */
const _ds6=doSell;
doSell=function(paidC){if(busy)return;const S_=ST(),C=cart.map(l=>({pid:l.pid,vid:l.vid||'',qty:l.qty,name:l.name}));
 if(!S_.noQty){const need={};for(const l of C){if(!l.vid)continue;const p=db.products.find(x=>x.id===l.pid),v=p&&hasV(p)&&p.vr.find(x=>x.id===l.vid);
  if(!v){alert(t('nostock')+l.name);return}const k=l.pid+'|'+l.vid;need[k]=(need[k]||0)+l.qty;
  if(!S_.allowNeg&&v.q<need[k]&&!(S_.sellZero&&v.q<=0)){alert(t('nostock')+l.name);return}}}
 const n0=db.sales.length;_ds6(paidC);
 if(db.sales.length>n0){const s=db.sales[db.sales.length-1],touched=new Set();
  C.forEach((l,i)=>{const p=db.products.find(x=>x.id===l.pid);if(!l.vid||!p||!hasV(p))return;const v=p.vr.find(x=>x.id===l.vid);if(s.lines[i])s.lines[i].vid=l.vid;
   if(v&&!S_.noQty){v.q=r3(v.q-l.qty);if(S_.sellZero&&!S_.allowNeg)v.q=Math.max(0,v.q);touched.add(p)}});
  touched.forEach(p=>{p.stock=vsum(p)});
  if(s.lines.every(l=>{const p=db.products.find(x=>x.id===l.pid);return p&&p.demo})&&(!s.cust||(db.customers.find(c=>c.id===s.cust)||{}).demo))s.demo=1;
  saveNow();R()}};

/* ---------- المنتجات والتفاصيل ---------- */
function rowP(p){return`<div class="row" onclick="pDet('${p.id}')">${phi(p)}<div style="flex:1;min-width:0"><b>${esc(p.name)}</b>${demoTag(p)}<div class="k">${esc(p.bc||'')}${p.fam?` · <span class="tag">${esc(p.fam)}</span>`:''}</div><div class="k">${ST().noQty?'':stockPill(p)}</div>${ST().noQty?'':vchips(p,8)}</div><div style="text-align:end"><b class="num">${M(p.price)}</b>${p.unit&&p.unit!=='u'?`<div class="k">/ ${esc(UL(p.unit))}</div>`:''}</div><button class="b sm" aria-label="${esc(t('edit'))}" onclick="event.stopPropagation();pForm('${p.id}')">${ic('pencil')}</button></div>`}
plH=function(){const A=db.products.filter(p=>!p.arch&&(!pf||p.fam===pf)&&(!pq||mt(p,pq)));if(pq)A.sort((a,b)=>mt(b,pq)-mt(a,pq));
 return(A.slice(0,plim).map(rowP).join('')||`<div class="k">${t('empty')}</div>`)+(A.length>plim?`<button class="b s" style="width:100%;margin-top:8px" onclick="plim+=100;pl()">${t('more')} (${A.length-plim})</button>`:'')};
const hint=txt=>hintsOn()?`<div class="al n hint">${ic('info')}<span>${txt}</span><button class="hx" aria-label="${esc(L('تخطي الشرح','Passer les conseils','Skip tips'))}" onclick="event.stopPropagation();hintsOff()">${ic('x')}</button></div>`:'';
function hintsOff(){db.onb=Object.assign(db.onb||{},{hintsOff:true});save();R()}
function pDet(id){const p=db.products.find(x=>x.id===id);if(!p)return;const u=UL(p.unit),dm=p.demo&&hintsOn();let vh='';
 if(hasV(p)){const G={};p.vr.forEach(v=>{const a=v.n.split(' / '),g=a.length>1?a[0]:'';(G[g]=G[g]||[]).push([v,a.length>1?a.slice(1).join(' / '):v.n])});
  vh=`<div class="k" style="margin:12px 0 4px;font-weight:700">${L('المقاسات والألوان','Tailles & couleurs','Sizes & colors')}</div>`+Object.entries(G).map(([g,a])=>`<div class="row" style="padding:7px 0"><b>${esc(g||p.name)}</b><span class="vcs" style="margin:0;justify-content:flex-end">${a.map(([v,lb])=>{const s=vst(p,v);return`<span class="vc ${s}">${esc(lb)} <b class="num">${s==='out'?L('نفد','Épuisé','Out'):fq(v.q)}</b></span>`}).join('')}</span></div>`).join('')}
 const ats=(p.at||[]).map(([k,v])=>`<div class="row" style="padding:7px 0"><span class="k">${esc(alb(k))}</span><b class="num" style="font-size:13.5px;text-align:end">${esc(pk(v))}</b></div>`).join('');
 const hs=dm?(hasV(p)?hint(L('يمكنك إدارة كل مقاس ولون بشكل مستقل.','Gérez chaque taille et couleur séparément.','Manage each size and color separately.')):p.unit==='ml'?hint(L('يمكنك البيع بالقارورة أو بالـml.','Vendez au flacon ou au ml.','Sell by the bottle or by the ml.')):['kg','g','m','l'].includes(p.unit)?hint(L('يُباع بالوزن أو بالمقدار: اكتب الكمية مباشرة (مثال 1.2).','Vendu au poids/à la mesure : saisissez la quantité (ex. 1,2).','Sold by weight/measure: type the quantity (e.g. 1.2).')):''):'';
 sheet(`<div class="bar" style="align-items:flex-start;gap:12px">${phi(p,46)}<div style="flex:1;min-width:0"><h3>${esc(p.name)}</h3><div class="k">${esc(p.fam||'')}${demoTag(p)}</div></div></div>
 <div class="bar" style="margin:10px 0;flex-wrap:wrap">${ST().noQty?'':stockPill(p)}<span class="k">${ST().noQty?'':remTxt(p)}</span></div>
 <div class="row" style="padding:7px 0"><span class="k">${t('price')}</span><b class="num">${M(p.price)} / ${esc(u)}</b></div><div class="row" style="padding:7px 0"><span class="k">${t('cost')}</span><b class="num">${M(p.cost)}</b></div>${p.p3?`<div class="row" style="padding:7px 0"><span class="k">${TN().p3}</span><b class="num">${M(p.p3)}</b></div>`:''}${p.bc?`<div class="row" style="padding:7px 0"><span class="k">${t('bc')}</span><b class="num ltr">${esc(p.bc)}</b></div>`:''}
 ${vh}${ats?`<div class="k" style="margin:12px 0 4px;font-weight:700">${L('التفاصيل','Détails','Details')}</div>${ats}`:''}${hs}
 <div class="bar" style="margin-top:14px"><button class="b" style="flex:1" onclick="ov.innerHTML='';go('pos');setTimeout(()=>addP('${p.id}'),40)">${ic('cart')} ${L('بيع','Vendre','Sell')}</button><button class="b s" onclick="ov.innerHTML='';pForm('${p.id}')">${ic('pencil')} ${t('edit')}</button><button class="b s" onclick="ov.innerHTML=''">${t('ok')}</button></div>`)}
const _vp6=VIEWS.prod;VIEWS.prod=()=>(db.products.some(p=>p.demo)?hint(L('هذه أمثلة توضح لك طريقة إضافة المنتجات.','Ces exemples vous montrent comment ajouter vos produits.','These examples show you how to add your products.')):'')+_vp6();
const _vi6=VIEWS.inv;VIEWS.inv=()=>(db.products.some(p=>p.demo)?hint(L('المخزون يتغير تلقائيًا مع كل عملية بيع.','Le stock change automatiquement à chaque vente.','Stock updates automatically with every sale.')):'')+_vi6();

/* ---------- نموذج المنتج: المقاسات والتفاصيل ---------- */
const vrRow=v=>`<div class="bar vrw" data-id="${esc(v.id||'')}"><input class="vn" placeholder="${esc(L('مثال: أسود / M','ex : Noir / M','e.g. Black / M'))}" value="${esc(v.n||'')}"><input class="vq" type="number" step="any" inputmode="decimal" placeholder="0" value="${v.q??''}"><button class="b sm r" aria-label="${esc(t('del'))}" onclick="this.parentNode.remove();vrChg()">${ic('x')}</button></div>`;
function vrChg(){const f=document.getElementById('f4');if(!f)return;const has=!!document.querySelector('#vrs .vrw');f.style.display=has?'none':'';if(f.previousElementSibling)f.previousElementSibling.style.display=has?'none':''}
function vrAdd(){const b=document.getElementById('vrs');if(!b)return;b.insertAdjacentHTML('beforeend',vrRow({id:'',n:'',q:''}));vrChg();const r=b.querySelectorAll('.vn');r[r.length-1].focus()}
const atTxt=p=>(p.at||[]).map(([k,v])=>alb(k)+': '+pk(v)).join('\n');
function atParse(s){return String(s||'').split('\n').map(l=>{const i=l.indexOf(':');if(i<1)return null;const k=l.slice(0,i).trim(),v=l.slice(i+1).trim();if(!k||!v)return null;return[ALR[k.toLowerCase()]||k,v]}).filter(Boolean)}
const _pf6=pForm;
pForm=function(id){_pf6(id);const p=db.products.find(x=>x.id===id)||{},fok=document.getElementById('fok');if(!fok)return;
 fok.parentNode.insertAdjacentHTML('beforebegin',`<label class="k">${L('المقاسات والألوان (اختياري)','Tailles & couleurs (facultatif)','Sizes & colors (optional)')}</label><div id="vrs">${(p.vr||[]).map(vrRow).join('')}</div><button class="b sm s" onclick="vrAdd()">${ic('plus')} ${L('إضافة مقاس / لون','Ajouter taille / couleur','Add size / color')}</button><div class="k" style="margin:4px 0 8px">${L('لكل مقاس أو لون مخزون مستقل، والمجموع يُحسب تلقائيًا.','Chaque variante a son propre stock ; le total est calculé.','Each variant has its own stock; the total is automatic.')}</div>
 <label class="k">${L('تفاصيل (سطر لكل خاصية، مثال: الماركة: Nike)','Détails (une ligne par champ, ex : Marque: Nike)','Details (one per line, e.g. Brand: Nike)')}</label><textarea id="pdt" rows="3">${esc(atTxt(p))}</textarea>`);vrChg();
 const o=fok.onclick;fok.onclick=function(){const rows=[...document.querySelectorAll('#vrs .vrw')].map(r=>({id:r.dataset.id||uid(),n:r.querySelector('.vn').value.trim(),q:Math.max(0,N(r.querySelector('.vq').value))})).filter(x=>x.n),dt=atParse((document.getElementById('pdt')||{}).value);
  o.apply(this,arguments);if(document.getElementById('fok'))return;
  const pr=id?db.products.find(x=>x.id===id):db.products[db.products.length-1];if(!pr)return;
  if(rows.length){const old=pr.vr||[];pr.vr=rows.map(r=>{const e=old.find(x=>x.id===r.id);return e?Object.assign(e,{n:r.n,q:r.q}):{id:r.id,n:r.n,q:r.q,bc:'',sku:''}});pr.stock=vsum(pr)}else if(pr.vr)delete pr.vr;
  if(dt.length)pr.at=dt;else if(pr.at)delete pr.at;
  if(id&&pr.demo)delete pr.demo;save();R()}};

/* ---------- الرئيسية: ابدأ هنا + منتجاتك ---------- */
let dci=null;
function dSet(i){dci=i;R()}
function startCard(){const dc=demoCount();if(!dc)return'';
 const it=(i,tx,fn)=>`<div class="sr" onclick="${fn}"><span class="ic">${ic(i)}</span><div class="st"><b>${tx}</b></div><span class="ar">${ic('next')}</span></div>`;
 return`<div class="card sh6"><div class="bar" style="justify-content:space-between;align-items:flex-start"><div><b>${ic('star')} ${L('ابدأ هنا','Commencez ici','Start here')}</b><div class="k" style="margin-top:2px">${DM()}: ${L('أمثلة للتعلّم، ولا تختلط ببيانات متجرك.','exemples pour apprendre, séparés de vos vraies données.','examples to learn from, kept apart from your real data.')}</div></div>${hintsOn()?`<button class="b sm s" onclick="hintsOff()">${L('تخطي','Passer','Skip')}</button>`:''}</div>
 ${hintsOn()?`<div class="sg" style="margin:10px 0 0">${it('cart',L('جرّب عملية بيع: اختر منتجًا وأتمّ الدفع','Faites une vente test : choisissez un produit','Try a sale: pick a product and pay'),"go('pos')")+it('boxes',L('شاهد كيف ينقص المخزون بعد البيع','Voyez le stock baisser après la vente','See stock drop after the sale'),"go('inv')")+it('plus',L('أضف منتجك الأول','Ajoutez votre premier produit','Add your first product'),'pForm()')}</div>`:''}
 <button class="b s sm" style="margin-top:10px" onclick="clearDemoAsk()">${ic('trash')} ${L('مسح البيانات التجريبية','Supprimer les données de démo','Clear demo data')}</button></div>`}
function yourProducts(){const ap=db.products.filter(p=>!p.arch);if(!ap.length)return'';const fs=fams();if(dci===null)dci=fs.length>1&&db.products.some(p=>p.demo)?0:-1;if(dci>=fs.length)dci=-1;
 const A=(dci>=0?ap.filter(p=>p.fam===fs[dci]):ap).slice(0,dci>=0?12:10);
 return`<div class="card"><div class="bar" style="justify-content:space-between;margin-bottom:6px"><b>${ic('package')} ${L('منتجاتك','Vos produits','Your products')}</b><span class="k" role="button" style="color:var(--pr);cursor:pointer" onclick="go('prod')">${t('all')} ${ic('next',14)}</span></div>
 ${fs.length>1?`<div class="chips"><span class="ch ${dci<0?'on':''}" onclick="dSet(-1)">${t('all')}</span>${fs.map((f,i)=>`<span class="ch ${dci===i?'on':''}" onclick="dSet(${i})">${esc(f)}</span>`).join('')}</div>`:''}
 ${A.map(p=>`<div class="row" onclick="pDet('${p.id}')">${phi(p)}<div style="flex:1;min-width:0"><b>${esc(p.name)}</b>${demoTag(p)}${ST().noQty?'':vchips(p,8)}</div>${ST().noQty?'':stockPill(p)}</div>`).join('')}</div>`}
const _vd6=VIEWS.dash;
VIEWS.dash=function(){let h=_vd6();const add=startCard()+yourProducts(),mk='<div class="card"><div class="bar" style="justify-content:space-between"><b>',i=h.indexOf(mk);return i>=0?h.slice(0,i)+add+h.slice(i):h+add};
const _vs6=VIEWS.set;
VIEWS.set=function(){const h=_vs6();if(sub||!demoCount())return h;return h+`<div class="k" style="margin:0 6px 6px">${DM()}</div><div class="sg">${SR(ic('trash'),L('مسح البيانات التجريبية','Supprimer les données de démo','Clear demo data'),L('سيتم حذف المنتجات والبيانات التجريبية فقط.','Seuls les produits et données de démo seront supprimés.','Only demo products and data will be deleted.'),String(demoCount()),'clearDemoAsk()')}</div>`};
const _R6=R;R=function(){vSyncAll();_R6()};

/* ---------- شاشة أول تشغيل ---------- */
const LOGO='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALAAAACwCAIAAAAg1XMJAAAaU0lEQVR42u1de5RUxZn/vqp7u6e7p6dnemaIiko2Ek6CyXEDRhZCdJGXgUEZFWQVgwkovmLMhvjK4q7rxqy6uycqJr7FrMpDR3mIMiCEbGLwmQ0YTyJqXEBQBubd069bVd/+Ud13enp6XswQerrrd/owTfftqrpVv/peVfcrrKgMCyEQEREBAIAACAAAEEB/YnCcQUQAkB6ggX3b0/Uu3B8SEWPM0h8hAoA6Ri02GCR679iBdjsiElFPv7IQqecCXVHRBx/6KiG7SUdBuX7/kHrvjWNQ5uDvrv81DmHXUdYFehAtAJb+iHr4AQ6iyqG6sX42hvoxeNjtysGXObScGNp+y3GbiD0Ot0VERDBMhD0N9UQ8po3EPGjGwGQbIlpAgESISIMdoZ5k0VGMK/U1M7CHK6mvWYvdSsCBtDZXuZQ2ypC6DQb2cOVR8zuTbb30EvXVMz3elIVDOWv7r3T71N9ZJbBBK3js6xMaRCdgDyVQX22gAcoS6rk6PKqRygYbgt4wKCBYhEBIueiFA5x2OPB5gP2ezdSX7hi8R3OUBnyGpsC+ruypRhxgSzCXnKBcmnFgco6ILAAEHExvYj8+PIr2Yb9Fa59GAB4zQmC/rUgcos97sYpo0LeTcjuzfpqfAcp89oKwYJqBiBaiAiAANvwD1czE3YfAhgBAIlYoUWfDgyGYVWjWIAz6498bGEIYGEKYLjAwhDAwhDDoJyFIr38bGBgJYZCDECYIYZAtIQwnDIwNYWBsCANDCANDCINBexnGqDQwEsLAEMLAEMLAEMLAEMLAEMLAEMLAEMLAEMLAEMLAEMLAEMJg2BDCbJAx6EIIs9ppYFSGQQ+EMHsqDYyEMOgR1nDZMaUzNPd6QepvZiLnzCTc3RNy91RgZzZoN6crAUEftecsLKslw4AQw6KViKiUytnviKkUniqVu50QQakuF2UORuZ7xphbsvsJESmlAIF0Ie712PUvYSZF9FVuYwBQ1+RWxzkfFtrZGhaCIRaP+X1+RYSQMwszAgAyPVR6cmdP0O4SgjEWj8eVUj6fT0qpxywejyNiSUlJiiVpCZFjILFL4djJnLSkYizzLqLRqMfj0YTLa0Jo2uat1mCMNTU1/ce9915wwdxkMsnSvewqCOiamC/3beRIEEmcW59++umVV1354YcfhkIhAGhrazvl5FOefPKJk08+2XEchr0NXp/Zl91PlSKvx/Pqtm3XXndtabBUC4/8nYEVlWEpZX4SwrKsxsNHbvunH//kzn87RlV89NFHNXNqPv74Y0AcNWrU+hfXfelLXzpGdf373XffesstlVVVQoq8nX75Swjbto80HP72okVPrVx5LFqIiFJKy7L27t07c+ZMQqjfvPnzoz4vhND6fmirU0pZlnX99dc/+OCDVSOqHcfJU0KEqyq1Bs03NjQ2Nk6bOnXjho22bSMgMlRKDeE4cc4BQErJOd+3fx8RjTp1lP5vyq4cOuZp00Hj4nkXr1u3rqq6Ouk4mN+EoDxJ8mhZVltb69gvj92+bXs4HFZK6Q4dWiHh2pi6fD2JXaNvyOvSFSFiJBKZOXPmW2+9VV5R7giRz4RQ+RCn4pzHYrGqyqrt27aNHj1aT1k9VHv27PnZffdZlpbn3Y4IcH2+7i4nZuQZRyaEM2rU52++6SYAUEQMUZFCAsxgw7333rt3317OuVLdD6XJqj1HWu50pZhMJq+95pozzjgj80b2798/ZcqUAwcP+gP+vBLPeUcIxpgQAgE2v7J54sSJQgjLsnQnHjp0aOrUqe+99x5yRkcvz7WDiiTVlUuW/OK/7mcBLyEwTEkIHaa75uqrH3r44cFVlPI8SarRo0fv2LFj5MiR+kY0M3bt2jVt2rRYIu7xeIZQPRWUDaGldEekY83q1bW1tZoNekjiycTsmpodO3ZUV1frQyWPVnQjgAKOmITG+JHFG1f8/NxrLCJgDJV2EdXiJUueWrmyakT14O0VIrIsq7GxccKECa9sejkYDOqjEPWt1dfXz62d6y0p6TMI+9ckBPf5/XnSGs55c1PTgytWXH755Sk2EGmTbPHixes3bBgxYoTjOJlsUESKlCJSBOk3vb0IJDGgmBAowj+/9Dfj6aOmhvPLv2opAo5CiMsuX/js08+Eq6uEEEopBf0tubMKogwFBVLK0mDpnvff//P77y+45BL3ToUQY8aMGTly5Nq1a/NnCBAxXwhh23bj4SO33HbrLTffrNmgZ5hS6rrrrnvi8Se8JSWRjoiTdOKJRCKRSCYS8UTcUsQcUPEkJAU4EpJ9vRxFUQmlzLqvtu280Rij3fKTP7d+dn7l1yDhzF+woO755yurq4SmHUOKCYgneyoZkxKSkpKCkgqSgpKSSVBCRmLReCKR1O1MJqPRqNfrfXfX7r17986aNUvHy7WcGD9uPGPslU0vlwZL80FxIGJeqAwdclh0xaKVT66UUrpLDIyx7du333777WWhMqlU9qFlBLua9rZzWVLmF+SgQgAEJB1wzhU9JAAkJdnVk9r//jTZEuEW58SSmLxMnB5fVle3YV24ukpqy58x1RHlXz0RwqXgKMDO83CyTlDTixiAigPG26MeB8+sOg27HUJiWVZba9stN99cU1PjujM6EHL1Ndc8/NBD+RCcyIvAFOe8qbFx+ozpG9dvtG07a/XVcRzbtnv6bf3B9y76n/vhpCD/fEXCAyBUxiDptSeWafwjITBKooSoAxxRAfmsqlbZvvQZ57X/K6sMKyEBAS0umiKe2tPV3TUxrw1K+x6k3QukDAcDERWBhR4H6S9HEvuafzn56ktOm9hTg13h5xoZRKRIXTB37ssvbTruk/P4E4IxlognTj997EsbXxoxYoQbEugeMOgOSWQxtuqDnQv/5z5WGcTRVaLMIocQGOU8lTA1nAiAyIikooAdahJs6Wrx5kGr3C+FQIaITLREvPPPSP57TUQ5JFR64QS7yhrNOQU22u2K9jSKw21PTL72O6efLZVEZNiz4ZwVwWSMHTlyZHbN7Hf/+MfOdbXjZVT6A8fThmCMtUfaH3hgxZnjxzuOkzl7emcDIjJEoeQZVaee7K9ev+d11pa0GUKohABQ6QScXV+Y/hcBFIHfDjXE4apnnXc+YyEfSYkMgTHZ0lGyaLxz1+x2kURJyJClDmZhblGAyAgAGefM/iwGHzSJprb7J3536VenCiUtxnuZYFlfIaLjOMFgcOTIkU8//UyJr+Q4DkdeGJWc8zffeHNOTU1lZaU2ILLNnFxIxwyYVPLM6r+ptss3fvwmRAniAkM+8nJCIERiWS8gTgQEAU/5wQhdtVbsOszLUmxAZKqlw3vlWfE7ZnYkE0wRMtShK7KQkKVKYAQMwWZMAn7cog5GRKTjP8769o1nfEsoxRnH9LzP2fJsOSelZVn79+9ftOiKSEfkWCyjDDOjknPe0tIy7mvjtmypryivyNIaLS0tjDHdTantDkCMMb/fnzLNgCQpC/mdv193+2v/XRasUAGuvlDOfBap7kfnEhCBxT0N7erGF+UfG1l5CQoBjBECtUY9102O3XxuNBZlBMQYSAVey58EiDmAmD5skYAxijv4USN0UKS99Z/OuuTOCfOFUpwxlw0dHR3utitKx8iFEOXl5VnbqCKRyMzzZr7+xhsVFRVHNRYDPQ22N4F9/DfISCnD4fDb77z9D/9w6Yb163X4wfUy3n777cWLF/sC/k4jADEWjS5ffvvi735X22gcuRBy+bi5yV//6d9+dGc4XOGQZF21D4ECN4TNmWzqUC0OKysBIYFxBJBtHZ4fnBP94dmxjigSEDIQDga9ZR+1wS0v0eEOsDB9hDMCAiWlhVZT0+Ebb/zhnRPmCyk555g2G5948ok77vjXQGnANQgYYntb+0MPPTR79mzXy9B+9cJvX75z587K6irhHN3SxlAuQuVFHEIpFQwG3921+8CBA3PnztXqgDGmlDrttNMA4Nlnnkk6yeaW5tbW1ra2tkgksvGljWO/PPYrX/mKEIIzhohSqWmTzm7Z37DjlVdLqUQ1RaE10fWVhLY4tCWoJc4cYl4LSOl9TSoSLVk2JfqP34xFogwYIAOpIOgN7WlXS9fI3YcwpqAl3llOa9xOQtOBQ1de+p0H7/mZVJIxxhA1G9Zv2LDoikXRWLStra21tbW1tbWjo+PAJweWLVu2ZMmSTJ+Tc37ttdc++8wzldVV4ugXumgIT5/Ll8CUUqo0WPq7137nCGfatGkqHY2QUk6aNCmRSGzftq0iXIGInHOPx8M5r3vhhfHjx40ZM0Y4gnOOiIrUrNmz9u3fv3Pn74LhcoWAFku/OFoMeeoFDIAIEUmBiia8t02Lfe8bsbaYtiRAKAh5y99voitXqf9r5yEfMkSLp1/o8XkbjzQuWLDgyadWEhLDTja8uu3V+ZfMtyyrxFvCObcsy+fzNTc2ff/GG396112aBK7p8M93/Mt//ed/DlprDxkbEJGX+Hx6Rh53ThCRPxDYUr+lvKJi0qRJQgg3QjV92rQ9H37wxs7Xy0IhTV8dsVj34ovfPPvsUaNOTRlxgEQ0p2bOn97/89tvvRkKhQCIM/dxRep+xrwiWfLj6dGlX4+1RhljwBCExJC3/N3D8so18EmMlXpBEQByzrQosi37yOHDs2bNXrVqlcU5EGhhxjl/5513amsvJCKv16v717btww0NF8+f99gjj7qWpqbOI48+8qMfLqsIh/NncQsRj3tgirLaAwDtbW2rV6+++KKL3RUNIorH47Nmz/r1jl+7i5CMcyWkL+B/edOmc84+R68baXInEokL5l6wpX4LckZS2R5PoDRApLpUx5lqjfmu/kbkX6dHD7ci5wAAQmLIH/rfQ2rpatkQw4AXpOKMEVBrSysQ6QXMs88556WXNgZLg3qMdaU7d+6ced7MSHtEVwqYWu2cOGlSfX19aSBAAK4g2bBx47x5F/v8/vxZ2er0MgazfjhoNmQ5AqkgPxBs2rTpm5MnZ24jOHy4oa7uBa319dYHi/NoLHbyyJG1tbXuDhp9cUtLy6pVq6SUgUDgvffee+TRR7nV2fUEiJxTS4f3jhnNS86SrTHkqIh4wBv8/SG5dA00xtHvASG5ZQkhpJI3/+imk048SSpJii666KLq6mrXIdJVb9iwYd++fT6fT0iRsl4RpRS1c2tPOOGEzLXvt95+a/qMGVIIO5/WvsFd/s4rQqTCl4lEWTC47dVtY8eOdbe19b+RmRd/8skn559//p4PPvB4LaVUOsQIKUL8eFrLdRNFawyByGeFdh2SV62hZsl8HCRxzqWUsVjs8ccev3zhwp6q6Gd7NCf+8pe/TDn33IaGBp/fl1ds0D1/fJ/+xq4GUUrN62clmpqbL543r6GhQUsILVpFLnTvVh3+A4B33nnn62edtXv3bk+JRylCZOgGHiHth2rTg4h5PPyNvXQwwgM2SGCMOY4Tj8aefOKJyxcudBxHCCGkFELkZIMOM3RHJhsaGxsvvOjCg58e9Pl9ebiVFfJgz1yWhUzuIlAwGHx/z/uXLLgkGo3qT9wdTVnQLlwm9JLY66+/XjOnprmlOVRRLoVkjEupEolEl7HsUjmBx4PcIkXIgIg8tufpp5++7NLLhBC2betIgx5d2Q164HMGVTUt4onEpQsv27V7dygUyttHH/L36W8hRHk4vONXO674zhWMMcuyeL9h2/Zvfvubmjk1La2tfr9fr5LEYrHyUPlXTj89mUgwTK1NUVprIQEDQEn6KRrGeFtb27dmfWvevHnuIot2eo8CuvFLl161ZXN9ZeVx1NF9Iw8f5etkp3CSldVVzz333DWV19bUzE4kEhlRbcy58kVEnPOGww3Lly+PRKN+n09Kadt2LB63LWvN6tXP19W99eZbXp9PP76L1LmUSWmBhZDar8vSol7P/samxl/96lec84xgcd/jSqQ8Hu/mzZt/+ctfhqursjZ9GUIMgBMIKISoCIcfe/yxhx95eEAhjdLSUl9JiZTSsq1YNFZSUvLc2ucmTpz46OOP9Rjt60YwUqRdAx1m+NOf/jzv4nloMRi4SGWcVYTDMo9lQ4oQ+Z8OQClVVlY2UL2mlNKj2BHpCJWV1dXVTf7GZKWUxa1++Ds9dBbnvoDf5/MdnZLNN58i9z3mx8O+rIdRSX0ipdbslOlHuM9QdB8efTvaTTjhc5+re75u/PjxiUTC6/V22TuDkF1jhhZAyH7UXBFpaZEeWoT+yopUiOQYhZwLXmXk7FHISgaS+SbnlGWMxWKxFStWjM+1+yZtTuZ4zj/3+27D2/lMTkYzhnsGt3wjBHaPZ2dq+QF1t34soqKiIufOvD4j6d3Zgohdt9hSmhvZHO3fbeYj8uoQNuwWqsr8b29qHhFT44WE2HklEQkhc7GBELO0AiJgeg+1O+6Uo4md5bOjEvvdb9PEIfruMpbu7gHplF7Ee6+SJP0XM6wCzF1oXqf7KCIbot/kwKMsVW/Rw6GtImtzGxpC/JUJgf2WHNoORXejZnoAU3qDsizGLoOM/WZD1mPjw4AQRZunktyHNTDT+8xSGcUHqwjuEXOZFIgIBISpPbOIlHIc3csJgIam3uFELZPJFomo88HNY+I3gSFEPg045nQpDIqREAr7sxiJQJjKT5ot8YvPjmCFfVgGUU9RA8oVc2I9GByD8WuNhBgenipidgoJhmQsKmAFrVPdnS49TnoCYDrgkMo0QplfIfXDKjEqY5grEcrky8AXIrCApxBR0QtJTLmciATUTSDk8EYL2klBRKM1O5WE8UcLPw6BfboFXU7gQMMLVkwioIcv0zthUCsN7EVBEBS6yVUMhMA+uEJZDmhfIqKwvYziNRkyXI0uX1KvZCIygakC5gYCEiMFgApJIQHL/WhhJj8KezWkwAnR+aheVxpkfE9d5AD1pW4QCzt4bdxOBGApX4P6dkqg4NcyqNAjLTk+yYw8IAISQ0KmkGU/F949I27BL4FaBR+6ptw2JLkaQDF0hAAiRMUAu2Y1z6ZTwR+VXgxb6HqTH4qDI5y7QjM9YC1LbBe8ywGsRYjCJ0S3E7FSme05Z3GlsCV+X3D2Db4zAaA0WnZry+uOdHzcj4ow12onmsBUQYJbViIWJ5/9yLk33OA/UypHkLM08LdPzfhHO+CLR2PM4jm1RsHvwCt8t7P78+SMs1g05vF4Xnihbv55NUJJzm2L2UKJOefOeHHduoDPH410dE/N39UKMYQoCHg8HiVVZWX45U0vnzdjppDCYjylPpklhDh3ypTNmzefdOJJTiJp2UVnYxU6IbplcGhuaj7l1FO3btn6dxMmCCEsbukM5Drlg2VZQohx48Zt3br1tNGnNTU15XJbTKRyODudrhWonwH/uwkTtmyp/+IXv9h58J/Oz5hOT29ZlpRy1KhRW+q3TJ70jaxUAgVvVBa+SKSuY3nDDTdA+mh2zQDG2LJly/RpvkSKCHRmzC984Qs33XRTVg6Qgjcqi05HuiRwU5Ff/73rH1zxIAC0d0R+8eDP3SSjblpME4coUBGRlhOIqKRknMfj8e8uWbzqmWfDVZUI8PAvHmpuan5q5cqSkhL3HANjVBaWTZlrhhMR47ylpeX8C87XbNA5iyurq9euWXPB3AuaW5pznn1VDMKi8N3OrGSAepg//vjjmjk1W7ds1UfZICIACZGsGlG1ZevWb82a9dFHH3a3GPLkYBFDiEFZDIFAIHNFSr+/8Qc/eO23r33uxBMz8soSACWTyRNOOOGNna8vvfpqnaDa/aFSKhAIGAkxvPWFUqp+c72bI921Ie772c++ec7Zhz791OPxZP7E47E/++yzM8/6+ooHVuhjm/QPtR26bdt2IUVhCwnu8/sLVRLqo45e2bw5Hk9Mnz49ZT0wBgAVFRUXXnjR7t27d/1hV7AsmI5KeRqPNE75+ynr16079dRT9cWaDZzzu++5+7bbbi0NBAvY80wd5FrYqtHn8726ZesnBw7MqalxvU2llK+kZP78+fs+2b/ztd+VBksZtxoPH5l/yfzn1j6njy9wT/JBxO9///s/+clPyspDhR2mLApCEFFpWelrv/nt7nffrZk121vidQebc147d257JLL91W2xjuj1N3zv8ccet21bf6UvSyaTi65Y9Nijj4WrKodFsurBOmXH+xC2v1a8xbIajxyZPHny2jVrTzzxxMzj3Rhjy5cvF1L89K6funaGZkNjY+NlCy+r31x/3M8//itZlIwVCyEAwLbtpsamsV/+cl1d3ZgxYzLXMvTtu+/1V/v27autrf39//6+sirfD7kYQglRROkAHMepCFfs2bNn6rSpO3fu1Aub7ilIbqBas+EPu/4wddrUXe/uKh42FEtgKhNCiGCorLGpaVbN7JdfeUVzAtKrnZA+uXv79u0zZszct39/KFReVGwoCqMyC0opj8fjOM6a1WtOPuWUcV/7misnNBuer3t+wYIFyWRSH5xXVItbxUgISB+bwDh7bu3a0kDp5MmTlVKklGVZ9z/wwFVLl1q2bXvsYuuW4iUEpE9WLfH5NqxfH4vFZsyYoX2N2269NVhW5p4UCkUGRCze5zK0TxGuqrznnnvaIu0e277/vvtDlWFIG5jF2S3H96jnvADnvLWtDYiCZUElFRTBPrle4hBF/eSWhpQyVFamXYxiZoOGIUSKE4YKxRiHMDCEMBiAlW0SlxrkkhBGdxpAei8ZA3OmiEGG1jAqw8AYlQaGEAb9NCMMIQyMDWFgVIaBIYSBIYSBIYSBIYSBcTsNjNtpYFSGgSGEgSGEQd4aEIYQBkZCGPTscyIiM9ulDIzbaWBUhkE/CWG2XBsYCWFgCGHQP0fDEMLASAgDQwgDQwgDQwgDQwgDQwgDQwgDQwgDQwgDQwgDQwiDvIXZIGNgJIRBr7CgH1noMo+k6vPKwW/S7KW6ISm/ADCE/ZBZFCJajDHbtgc0VFlaJ2f7Mk/S7UldZX7Vy+3porqzpD9V9NTs/mjT3m+5l5Kzbi1nX/X+w8wLcl7cUwm930uftGCM/T+imeqxRbR8dAAAAABJRU5ErkJggg==';
let onbStep=0;const onbSel=new Set();
const onbEl=()=>document.getElementById('onb');
function onbShow(){let o=onbEl();if(!o){o=document.createElement('div');o.id='onb';document.body.appendChild(o)}document.body.classList.add('onbo');onbR()}
function onbClose(){const o=onbEl();if(o)o.remove();document.body.classList.remove('onbo');tab='dash';sub='';R();scrollTo(0,0)}
function onbLang(l){setLang(l);onbR()}
function onbR(){const o=onbEl();if(!o)return;
 const lg=`<div class="onb-lg">${[['ar','العربية'],['fr','Français'],['en','English']].map(([k,n])=>`<button class="${LG()===k?'on':''}" onclick="onbLang('${k}')">${n}</button>`).join('')}</div>`;
 if(onbStep===0){o.innerHTML=`<div class="onb-w">${lg}<div class="onb-c"><img class="onb-logo" src="${LOGO}" alt="TASYIR" width="112" height="112"><h1>${L('مرحبًا بك في','Bienvenue sur','Welcome to')} <span dir="ltr">TASYIR</span></h1><p>${L('البيع والمخزون والديون والمصاريف، كلها في مكان واحد وتعمل بدون إنترنت.','Ventes, stock, dettes et dépenses au même endroit, sans internet.','Sales, stock, debts and expenses in one place, working offline.')}</p></div><div class="onb-f"><button class="b" onclick="onbNext()">${L('ابدأ','Commencer','Start')} ${ic(LG()==='ar'?'prev':'next')}</button></div></div>`;return}
 const n=onbSel.size;
 o.innerHTML=`<div class="onb-w"><div class="onb-h"><button class="hb" aria-label="${esc(L('رجوع','Retour','Back'))}" onclick="onbBack()">${ic(LG()==='ar'?'next':'prev')}</button><div style="flex:1"><h2>${L('ما نوع تجارتك؟','Quel est votre commerce ?','What do you sell?')}</h2><p>${L('اختر نشاطًا أو أكثر، وسنجهّز لك أمثلة جاهزة.','Choisissez une ou plusieurs activités, nous préparons des exemples.','Pick one or more, we will prepare ready examples.')}</p></div></div>
 <div class="onb-g">${CATS.map(c=>`<button class="cc ${onbSel.has(c.id)?'on':''}" onclick="onbTog('${c.id}')" aria-pressed="${onbSel.has(c.id)}"><span class="ci">${ic(c.ic)}</span><b>${esc(pk(c.n))}</b><i class="ck">${ic('check')}</i></button>`).join('')}</div>
 <div class="onb-f"><button class="b" id="onbgo" ${n?'':'disabled'} onclick="onbGo()">${L('ابدأ الآن','Commencer','Start now')}${n?` · ${n}`:''}</button><button class="onb-sk" onclick="onbSkip()">${L('تخطي، سأبدأ بمتجر فارغ','Passer, démarrer sans exemples','Skip, start with an empty shop')}</button></div></div>`}
function onbNext(){onbStep=1;onbR()}
function onbBack(){onbStep=0;onbR()}
function onbTog(id){if(onbSel.has(id))onbSel.delete(id);else onbSel.add(id);onbR()}
function onbGo(){if(!onbSel.size)return;try{seedDemo([...onbSel])}catch(e){onErr(e.message);return}onbClose();toast('[ok] '+L('جاهز! أضفنا أمثلة تجريبية لنشاطك','Prêt ! Exemples ajoutés pour votre activité','Ready! Demo examples added for your trade'))}
function onbSkip(){db.onb={done:1,skipped:1,at:Date.now()};saveNow();onbClose()}
function onbBoot(){if(db.onb&&db.onb.done)return;
 const fresh=!db.products.length&&!db.sales.length&&!db.customers.length&&!db.expenses.length&&!db.ledger.length&&!(db.suppliers||[]).length&&!(db.workers||[]).length&&!(db.settings&&db.settings.lastBackup);
 if(!fresh){db.onb={done:1,legacy:1};saveNow();return}onbShow()}
Object.assign(window,{clearDemo,clearDemoAsk,pDet,pickV,pickQ,addVar,addQ,vrChg,vrAdd,hintsOff,dSet,onbLang,onbNext,onbBack,onbTog,onbGo,onbSkip});
try{vSyncAll();onbBoot()}catch(e){onErr(e.message)}
})();
