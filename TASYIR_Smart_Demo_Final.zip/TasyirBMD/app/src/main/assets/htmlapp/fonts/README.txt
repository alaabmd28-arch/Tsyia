ضع هنا ملف الخط المحلي باسم:  TasyirSans.woff2

الخطوط الموصى بها (كلها مجانية بترخيص OFL وتدعم العربية واللاتينية والأرقام):
  - Cairo (متغيّر Variable)           https://fonts.google.com/specimen/Cairo
  - IBM Plex Sans Arabic              https://fonts.google.com/specimen/IBM+Plex+Sans+Arabic
  - Noto Sans Arabic                  https://fonts.google.com/specimen/Noto+Sans+Arabic

حوّل ملف TTF إلى WOFF2 (مثلًا بالأداة https://cloudconvert.com/ttf-to-woff2 أو الأمر: woff2_compress)، ثم سمّه TasyirSans.woff2.
لا حاجة لتعديل أي كود: app.css يحمّله تلقائيًا، وإن غاب الملف يستعمل التطبيق خط النظام العربي.
(الحجم المناسب بعد ضغط Cairo Variable نحو 100–150 KB.)
