package com.mycompany.tasyirbmd

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File

class MainActivity : AppCompatActivity() {

    private var web: WebView? = null
    private var pendingWebPermission: PermissionRequest? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingScanMulti: Boolean? = null

    private val cameraPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            onCameraPermissionResult(granted)
        }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val cb = fileCallback
            fileCallback = null
            val uris = try {
                WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            } catch (e: Exception) {
                null
            }
            cb?.onReceiveValue(uris)
        }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this
        try {
            setupWebView()
        } catch (e: Exception) {
            Log.e(TAG, "WebView init failed", e)
            AlertDialog.Builder(this)
                .setMessage("تعذر تشغيل WebView. حدّث تطبيق Android System WebView من متجر Play ثم أعد المحاولة.")
                .setPositiveButton(R.string.ok) { _, _ -> finish() }
                .setCancelable(false)
                .show()
            return
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
    }

    override fun onPause() {
        // لا نستدعي web.onPause() حتى لا تتوقف الصفحة أثناء فتح الماسح
        super.onPause()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        pendingWebPermission?.deny()
        pendingWebPermission = null
        web?.let {
            it.stopLoading()
            it.removeJavascriptInterface("Android")
            it.destroy()
        }
        web = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val w = WebView(this)
        web = w
        setContentView(w)

        with(w.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage (كل بيانات المتجر)
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
            builtInZoomControls = false
            textZoom = 100
        }

        w.addJavascriptInterface(Bridge(), "Android")

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                return if (url.scheme == "file") {
                    false
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, url))
                    } catch (e: ActivityNotFoundException) {
                        toast("لا يوجد تطبيق لفتح هذا الرابط")
                    }
                    true
                }
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // انهيار عملية WebView: نعيد بناء الشاشة بدل إغلاق التطبيق
                Log.e(TAG, "Render process gone, crashed=${detail.didCrash()}")
                runOnUiThread { recreate() }
                return true
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (request.isForMainFrame) {
                    view.loadUrl("file:///android_asset/htmlapp/helpers/error.html")
                }
            }
        }

        w.webChromeClient = object : WebChromeClient() {

            // ---- الكاميرا داخل الصفحة (OCR وغيره) ----
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                        request.deny()
                        return@runOnUiThread
                    }
                    if (hasCameraPermission()) {
                        grantWebCamera(request)
                    } else {
                        pendingWebPermission?.deny()
                        pendingWebPermission = request
                        cameraPermLauncher.launch(Manifest.permission.CAMERA)
                    }
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingWebPermission === request) pendingWebPermission = null
            }

            // ---- اختيار الملفات (استيراد Excel / استعادة نسخة / صورة منتج) ----
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    toast("تعذر فتح منتقي الملفات")
                    false
                }
            }

            // ---- alert / confirm ----
            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                if (isFinishing) {
                    result.cancel()
                    return true
                }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                if (isFinishing) {
                    result.cancel()
                    return true
                }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        w.loadUrl(START_URL)
    }

    private fun handleBack() {
        val w = web
        if (w == null) {
            finish()
            return
        }
        val js = "(function(){try{" +
            "var s=document.getElementById('sv'),o=document.getElementById('ov');" +
            "if(s&&s.innerHTML){stopScan();return 1}" +
            "if(o&&o.innerHTML){o.innerHTML='';return 1}" +
            "if(typeof tab!=='undefined'&&tab!=='dash'){tab='dash';R();return 1}" +
            "}catch(e){}return 0})()"
        w.evaluateJavascript(js) { r ->
            if (r?.trim() != "1") confirmExit()
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setMessage(R.string.exit_confirm)
            .setPositiveButton(R.string.yes) { _, _ -> finish() }
            .setNegativeButton(R.string.no, null)
            .show()
    }

    // ------------------------------------------------------------------ camera permission

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun grantWebCamera(request: PermissionRequest) {
        try {
            request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
        } catch (e: Exception) {
            Log.e(TAG, "grant failed", e)
        }
    }

    private fun onCameraPermissionResult(granted: Boolean) {
        val scanMulti = pendingScanMulti
        val req = pendingWebPermission
        pendingScanMulti = null
        pendingWebPermission = null
        if (granted) {
            if (scanMulti != null) launchScanner(scanMulti)
            if (req != null) grantWebCamera(req)
        } else {
            req?.deny()
            if (scanMulti != null || req != null) showPermissionDeniedDialog()
        }
    }

    private fun showPermissionDeniedDialog() {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle(R.string.perm_title)
            .setMessage(R.string.perm_msg)
            .setPositiveButton(R.string.open_settings) { _, _ -> openAppSettings() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun openAppSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ------------------------------------------------------------------ scanner

    private fun startScan(multi: Boolean) {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            toast(getString(R.string.no_camera))
            return
        }
        if (hasCameraPermission()) {
            launchScanner(multi)
        } else {
            pendingScanMulti = multi
            cameraPermLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun launchScanner(multi: Boolean) {
        try {
            startActivity(Intent(this, ScannerActivity::class.java).putExtra(ScannerActivity.EXTRA_MULTI, multi))
        } catch (e: Exception) {
            Log.e(TAG, "scanner launch failed", e)
            toast(getString(R.string.camera_error))
        }
    }

    /** يستدعيه ScannerActivity عند قراءة باركود، ويعيد نتيجة الصفحة (نجاح/رسالة) */
    fun dispatchScan(code: String, cb: (Boolean, String) -> Unit) {
        val w = web
        if (w == null) {
            cb(false, "")
            return
        }
        val js = "(function(){try{return window.__ns(" + JSONObject.quote(code) +
            ")}catch(e){return JSON.stringify([0,String(e)])}})()"
        w.evaluateJavascript(js) { raw ->
            var ok = true
            var msg = ""
            try {
                val s = JSONTokener(raw ?: "null").nextValue() as? String
                if (s != null) {
                    val a = JSONArray(s)
                    ok = a.optInt(0, 1) == 1
                    msg = a.optString(1, "")
                }
            } catch (e: Exception) {
                Log.w(TAG, "scan result parse", e)
            }
            cb(ok, msg)
        }
    }

    // ------------------------------------------------------------------ files / print

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray) {
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("insert failed")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IllegalStateException("stream failed")
            toast(getString(R.string.saved, "Download/$safe"))
        } else {
            // أندرويد 7-9: نحفظ ثم نفتح نافذة المشاركة (حفظ في Drive / واتساب / ملفات...)
            val dir = File(cacheDir, "exports").apply { mkdirs() }
            val f = File(dir, safe)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, safe))
        }
    }

    private fun printPage() {
        val w = web ?: return
        try {
            val pm = getSystemService(PRINT_SERVICE) as PrintManager
            pm.print("Tasyir_bmd", w.createPrintDocumentAdapter("Tasyir_bmd"), PrintAttributes.Builder().build())
        } catch (e: Exception) {
            Log.e(TAG, "print failed", e)
            toast("تعذرت الطباعة")
        }
    }

    // ------------------------------------------------------------------ JS bridge

    inner class Bridge {
        @JavascriptInterface
        fun scan(multi: Boolean) {
            runOnUiThread { startScan(multi) }
        }

        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String): Boolean {
            return try {
                saveToDownloads(name, mime, Base64.decode(base64, Base64.DEFAULT))
                true
            } catch (e: Exception) {
                Log.e(TAG, "save failed", e)
                toast(getString(R.string.save_failed))
                false
            }
        }

        @JavascriptInterface
        fun print() {
            runOnUiThread { printPage() }
        }

        @JavascriptInterface
        fun openSettings() {
            runOnUiThread { openAppSettings() }
        }
    }

    companion object {
        private const val TAG = "TasyirBMD"
        // نفس عنوان النسخة القديمة => نفس مساحة localStorage => لا تضيع بيانات المتجر عند التحديث
        private const val START_URL = "file:///android_asset/htmlapp/root/index.html"

        @Volatile
        var instance: MainActivity? = null
    }
}
