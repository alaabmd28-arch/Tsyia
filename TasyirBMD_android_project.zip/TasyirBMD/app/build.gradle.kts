plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mycompany.tasyirbmd"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mycompany.tasyirbmd"   // نفس الحزمة القديمة => التحديث يحافظ على البيانات
        minSdk = 24
        targetSdk = 34
        versionCode = 101
        versionName = "1.1"
    }

    signingConfigs {
        create("release") {
            // نفس مفتاح التوقيع القديم (ضروري ليُثبَّت كتحديث فوق النسخة الحالية)
            storeFile = file("tasyirbmd.jks")
            storePassword = "Fa56KhUYxwRU"
            keyAlias = "tasyirbmd"
            keyPassword = "Fa56KhUYxwRU"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    // ماسح الباركود يعمل بدون إنترنت
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
}
